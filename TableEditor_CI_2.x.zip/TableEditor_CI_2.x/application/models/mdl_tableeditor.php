<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
 * Created on 30.12.2009
 */


/**
 * This class is responsible for accessing the wanted tables from the DB
 *
 * @package		TableEditor
 * @subpackage	Models
 * @category	Models
 * @author		Oliver Mischa Voegeli
 * @version		0.3
 * @link		
 */
class Mdl_tableeditor extends CI_Model {

	private $objMeta;			// Class-instance TE_tableEditor_meta
	//private $objController;		// Class-instance tableEditor
	const COL_ID			= 'Id';
	const COL_CREATEDATE	= 'HdCreateDate';
	const COL_ORDER			= 'HdOrder';
	
	
	public function __construct()
	{
		parent::__construct();
	}

	
	/**
	 * Takes the instance from class TE_tableEditor_meta
	 *
	 * @access	public
	 * @param	Object	objMeta		TE_tableEditor_meta
	 * @return	void
	 */
	public function setObjMeta(&$objMeta)
	{
		$this->objMeta = $objMeta;
	}
	/**
	 * Takes the instance from class tableEditor
	 *
	 * @access	public
	 * @param	Object	objController		tableEditor
	 * @return	void
	 */
	/*public function setObjController($objController)
	{
		$this->objController = $objController;
	}*/
	
	
	/**
	 * Gets the tables content according to the wanted columns and returns it
	 *
	 * @access	public
	 * @return	Object
	 */
	public function getTableOverview()
	{
		$tableName = $this->objMeta->getTableName();
		$arrColumn = $this->objMeta->getSelectArray(TE_CONST::LEAVE_OVERWIEW);
		$arrColumn = $this->_appendStandardColumns($arrColumn);
		$this->db->select( implode(", ", $arrColumn) );
		$orderBy = $this->objMeta->getOrderBy();
		if (strlen($orderBy) > 0)
			// OrderBy - columns have been defined
			$this->db->order_by($orderBy);
		else {
			// If manual order-feature is enabled, sort it according to the order-column
			if ($this->objMeta->checkIsManualOrderEnabled() == true)
				$this->db->order_by(self::COL_ORDER);
			else
				$this->db->order_by(self::COL_ID);
		}
		
		$query = $this->db->get($tableName);
		
		// Hooks before passing data to view...
		// Also add all virtual fields to the result-set
		$metaOverview =& $this->objMeta->getOverviewMeta();
		$arrHookPreRenderOverview = $this->objMeta->getHooksPreRenderOverview();
		foreach($query->result() as $row)
		{
			
			$rowCopy = clone $row;
			foreach($metaOverview as &$metaItem) {
				if ($metaItem[TE_CONST::LEAVE_VIRTUAL] == true) {
					$colName = $metaItem[TE_CONST::LEAVE_COLUMN];
					$row->$colName = "";
				}
				$this->_callHooksPreRenderOverview($arrHookPreRenderOverview, $metaItem[TE_CONST::LEAVE_COLUMN], $row->{$metaItem[TE_CONST::LEAVE_COLUMN]}, $rowCopy);
			}
		}
		
		return $query;
	}
	
	
	/**
	 * Gets a single entry from a table
	 *
	 * @access	public
	 * @param	string	tableName	Name of table
	 * @param	string	id			Table.Id
	 * @param	array	arrColumn	Columns of the table, strings
	 * @return	Object
	 */
	public function getItemById($tableName, $id)
	{
		//$tableName = $this->objMeta->getTableName();
		$arrColumn = $this->objMeta->getSelectArray(TE_CONST::LEAVE_DETAIL);
		$arrColumn = $this->_appendStandardColumns($arrColumn);
		$this->db->select( implode(", ", $arrColumn) );
		$this->db->where(array(self::COL_ID => $id));
		$query = $this->db->get($tableName);
		return $query;
	}
	
	
	/**
	 * Saves or adds an item to the table, depending if id is set to false or not. It also will check for the
	 * as unique defined columns if the passed value is unique. Otherwise an exception will be risen.
	 *
	 * @access	public
	 * @param	string	id			Table.Id - if set to false, new entry is generated
	 * @param	array	data		Columns of the table, strings
	 * @return	bool
	 */
	public function itemSave($id, $data)
	{
		$tableName = $this->objMeta->getTableName();
		$arrMeta = $this->objMeta->getDetailMeta();
		foreach($arrMeta as $itemMeta)
		{
			// Check if values marked as unique will be unique for sure!
			if ($itemMeta[TE_CONST::LEAVE_UNIQUE] == true && isset($itemMeta[TE_CONST::LEAVE_COLUMN]) )
			{
				
				$this->db->where($itemMeta[TE_CONST::LEAVE_COLUMN], $data[$itemMeta[TE_CONST::LEAVE_COLUMN]] );
				$query = $this->db->get($tableName);
				if ($query->num_rows() > 0 && $query->row_object()->{self::COL_ID} != $id )
					// Oops, a value was marked as unique, but the passed one does already exist in another row
					throw new TE_Exception_DB( sprintf($this->lang->line('te_msg_valueNotUnique'), $itemMeta[TE_CONST::LEAVE_LABEL], $data[$itemMeta[TE_CONST::LEAVE_COLUMN]]) );
			}
		}
		
		// Hooks before saving...
		$arrHooksPreSave = $this->objMeta->getHooksPreSave();
		if (count($arrHooksPreSave) > 0) {
			$oldData = $this->db->get_where($tableName, array(self::COL_ID => $id))->row_array();
			$this->_callHooksPreSave($arrHooksPreSave, $data, $oldData);
		}
		
		if ($id !== false)
		{
			// Update
			$this->db->where(self::COL_ID, $id);
			$this->db->update($tableName, $data);
		} else {
			// Insert
			if (!isset($data[self::COL_CREATEDATE]) || strlen(trim($data[self::COL_CREATEDATE])) == 0 )
				// Append standard createdate-column
				$data[self::COL_CREATEDATE] = date("Y-m-d H:i:s", time());
			
			$this->db->select_max(self::COL_ORDER);
			$row = $this->db->get($tableName)->row_object();
			$data[self::COL_ORDER] = $row->{self::COL_ORDER} + 1;
			
			$this->db->insert($tableName, $data); 
		}
		return true;
	}
	
	
	/**
	 * Deletes an item from a table. Also checks if there is/are delete-restrict constraints contained, which would trigger an Exception.
	 *
	 * @access	public
	 * @param	string	id			Table.Id - if set to false, new entry is generated
	 * @return	object
	 */
	public function itemDelete($id)
	{
		$tableName = $this->objMeta->getTableName();
		$arrMeta = $this->objMeta->getDetailMeta();
		foreach($arrMeta as $itemMeta)
		{
			// Check if there are delete-restricts set in the metadata. If yes, check if value(s) are not reference from the defined tables
			foreach ($itemMeta[TE_CONST::LEAVE_DELETE_RESTR] as $itemDelete)
			{
				if ( strlen($itemDelete) > 0 )
				{
					$arrTableCol = explode  ( ".", $itemDelete );
					if (count($arrTableCol) != 2)
						// Bang! The set delete_restrict - node is not in the expected format 'table'.'column'
						throw new TE_Exception("Following delete_restrict - node is not in the expected format: $itemDelete. It should be 'table'.'column' (without quotes).", __METHOD__);
					//print_r($arrTableCol);
					
					$query = $this->getItemById($tableName, $id);
					if ($query->num_rows() == 0) {continue;}
					
					$this->db->where($arrTableCol[1], $query->row_object()->$itemMeta[TE_CONST::LEAVE_COLUMN] );
					$query = $this->db->get($arrTableCol[0]);

					if ( $query->num_rows() > 0 )
						throw new TE_Exception_DB( sprintf($this->lang->line('te_msg_deleteRestrict'), $itemMeta[TE_CONST::LEAVE_LABEL], $arrTableCol[0]) );
				}
			}
		}
		
		// Hooks before deleting...
		$arrHooksPreDelete = $this->objMeta->getHooksPreDelete();
		if (count($arrHooksPreDelete) > 0) {
			$oldData = $this->db->get_where($tableName, array(self::COL_ID => $id))->row_array();
			$this->_callHooksPreDelete($arrHooksPreDelete, $oldData);
		}
		
		$this->db->limit(1);
		$this->db->where(self::COL_ID, $id);
		return $this->db->delete($tableName);
	}
	
	
	/**
	 * Changes the order of an item in a table, per default the order is set in the field 'Position'
	 * 
	 * @access	public
	 * @param	string	id			Item's id which needs to be moved
	 * @param	string	direction	The direction in which the item needs to be moved: 'up' / 'down'
	 * @return	boolean
	 */
	public function itemMove($id, $direction)
	{
		$tableName = $this->objMeta->getTableName();
		$query = $this->db->get_where($tableName, array(self::COL_ID => $id));
		$currPos = $query->row_object()->{self::COL_ORDER};
		
		if ($direction == 'up') {
			// Order of item: up
			$this->db->where(self::COL_ORDER . " < " . $currPos);
			$this->db->select_max(self::COL_ORDER);
		} else {
			// Order of item: down
			$this->db->where(self::COL_ORDER . " > " . $currPos);
			$this->db->select_min(self::COL_ORDER);
		}
		$newPos = $this->db->get($tableName)->row_object()->{self::COL_ORDER};

		$this->db->where(self::COL_ORDER, $newPos);
		$this->db->trans_start();
		$this->db->update($tableName,array(self::COL_ORDER => $currPos));
		$this->db->where(self::COL_ID, $id);
		$this->db->update($tableName,array(self::COL_ORDER => $newPos));
		$this->db->trans_complete();
	}
	
	
	/**
	 * Sets the search-items in the db-class into the where-clause; Does some parsing for wildcards (*) or ranges (12...45)
	 * 
	 * @access	public
	 * @param	array	arrSearchItem	Array containing the search-items: column/value - pairs
	 * @return	void
	 */
	public function setSearchItem($arrSearchItem)
	{
		foreach($arrSearchItem as $column => $value)
			$this->_parseSearchItem($column, $value);
	}
	
	
	/**
	 * Reads a lookup-table and returns array with key / value - pairs
	 * 
	 * @access	public
	 * @param	string	$tablename		Name of lookup-table
	 * @param	string	$idColumn		Name of Id-column
	 * @param	string	$valueColumn	Name of value-column
	 * @return	array
	 */
	public function getLookupTable($tablename, $idColumn, $valueColumn)
	{
		$this->db->select("$idColumn,$valueColumn");
		if ($this->objMeta->checkIsManualOrderEnabled() == true)	// If manual order-feature is enabled, order it according to that column
			$this->db->order_by(self::COL_ORDER);
		else
			$this->db->order_by(self::COL_ID);
		$query = $this->db->get($tablename);
		$resArr = array();
		foreach($query->result() as $row)
			$resArr[$row->{$idColumn}] =  $row->$valueColumn;
		return $resArr;
	}
	
	
	/**
	 * Checks if a given tablename exists in the DB
	 *
	 * @access	public
	 * @param	string	tableName	Table's name
	 * @return	boolean
	 */
	public function tableExists($tableName)
	{
		if (strlen($tableName) == 0 || is_numeric($tableName)) return false;
		$query = $this->db->query("CHECK TABLE $tableName");
		if (strtolower($query->row_object()->Msg_text) !== "ok")
			return false;
		return true;
	}
	
	
	/**
	 * Appends to the column-array standard-columns like Id and HdCreateDate, if not existing
	 *
	 * @access	private
	 * @param	array	arrColumn	Columns of the table, strings
	 * @return	array
	 */
	private function _appendStandardColumns($arrColumn)
	{
		if (!isset($arrColumn[self::COL_ID]))
			$arrColumn[] = self::COL_ID;
		if (!isset($arrColumn[self::COL_CREATEDATE]))
			$arrColumn[] = self::COL_CREATEDATE;
		return $arrColumn;
	}
	
	
	/**
	 * Calls the passed hooks
	 *
	 * @access	private
	 * @param	array	arrHooks	Array containing all hook-methods which need to be called
	 * @param	array	newData		Array containing all the DB-fields which will be saved to the DB (by reference!)
	 * @param	array	oldData		Array containing the complete row of the table with the old data (empty if new entry)
	 * @return	void
	 */
	private function _callHooksPreSave($arrHooks, &$newData, $oldData)
	{
		if (count($arrHooks) > 0 && !isset($this->tableeditor_hooks) )
			$this->load->library('tableEditor_hooks');
		
		foreach($arrHooks as $hookMethod)
		{
			$this->_checkHookMethod($hookMethod);
			$this->tableeditor_hooks->$hookMethod($newData, $oldData);
		}
	}
	/**
	 * Calls the passed hooks
	 *
	 * @access	private
	 * @param	array	arrHooks	Array containing all hook-methods which need to be called
	 * @param	array	oldData		Array containing the complete row of the table with the old data (empty if new entry)
	 * @return	void
	 */
	private function _callHooksPreDelete($arrHooks, $oldData)
	{
		if (count($arrHooks) > 0 && !isset($this->tableeditor_hooks) )
			$this->load->library('tableEditor_hooks');
		
		foreach($arrHooks as $hookMethod)
		{
			$this->_checkHookMethod($hookMethod);
			$this->tableeditor_hooks->$hookMethod($oldData);
		}
	}
	/**
	 * Calls the passed hooks
	 *
	 * @access	private
	 * @param	array	arrHooks	Array containing all hook-methods which need to be called
	 * @param	string	label		Contains the label as defined in the metadata (by reference!)
	 * @param	string	data		Contains the data from DB (by reference!)
	 * @return	void
	 */
	private function _callHooksPreRenderOverview($arrHooks, $columnName, &$columnData, $rowData)
	{
		if (count($arrHooks) > 0 && !isset($this->tableeditor_hooks) )
			$this->load->library('tableEditor_hooks');
		
		foreach($arrHooks as $hookMethod)
		{
			$this->_checkHookMethod($hookMethod);
			$this->tableeditor_hooks->$hookMethod($columnName, $columnData, $rowData);
		}
	}
	/**
	 * Checks if the passed hook-method exists in tableEditor_hooks - if not, throws exception.
	 *
	 * @access	private
	 * @param	string	hookMethod	Hook-Method which needs to be checked
	 * @return	void
	 */
	private function _checkHookMethod($hookMethod)
	{
		if (!method_exists($this->tableeditor_hooks, $hookMethod))
			throw new TE_Exception("The hook-method '$hookMethod' is not defined in libraries/tableeditor_hooks.", __METHOD__);
	}
	
	
	/**
	 * Helper to parse the search-items for numeric ranges and wildcards. Sets the values into the db-class (where-clause)
	 * 
	 * @access	private
	 * @param	string		column	Column's name
	 * @param	string		value	Search-value which is parsed first
	 * @return	void
	 */
	private function _parseSearchItem($column, $value)
	{
		if (is_numeric($value)) {
			$this->db->where($column, $value);							// Single numeric value
			return;
		}
		$arrSplit = explode("...", $value);
		if (count($arrSplit) == 2 && is_numeric($arrSplit[0]) && is_numeric($arrSplit[1]))
		{
			$this->db->where($column.' >=', $arrSplit[0]);				// Numeric range, e.g. 12...23
			$this->db->where($column.' <=', $arrSplit[1]); 
			return;
		}
		// From here we expect a string
		$value = str_replace('%','\%',$value);			// Escape '%'
		$value = str_replace('_','\_',$value);			// Escape '_'
		$value = str_replace('*','%',$value);			// Replace own wildcard '*'
		$value = str_replace('?','_',$value);			// Replace own wildcard '?'
		$this->db->where($column.' LIKE', $value); 
	}
	
}
// ******************************************** END CLASS Mdl_tableEditor *********************************************




/**
 * This class is responsible for reading the metadata from the config-file tableEditor_metadata and
 * holding its data
 *
 * @package		TableEditor
 * @subpackage	Models
 * @category	Models
 * @author		Oliver Mischa Voegeli
 * @link		
 */
class TE_tableEditor_meta
{
	
	// Don't chanche these variables!
	private $tableMeta =	array();
	private $configFilename = 'tableEditor_metadata';
	private $tableName;
	private $CI;
	private $arrHookPreSaveItem = array();			// Array containing methods which are to be called before item is saved to DB
	private $arrHookPreDeleteItem = array();		// Array containing methods which are to be called before item is deleted from DB
	private $arrHookPreRenderOverview = array();	// Array containing methods which are to be called before the overview is rendered
	private $hookFileExistanceChecked = false;
	private $isFileUpload = false; // If one of the input-types is defined as 'file', this will be set to true
	
	
	
	public function __construct($tableName)
	{
		$this->CI =& get_instance();
		$this->tableName = $tableName;
		$this->_loadMetadata();
	}
	
	// Forbids copies of the object
	private function __clone() {}
	
	
	/**
	 * Builds the select-array according to param)
	 *
	 * @access	public
	 * @param	string	leave	Constant LEAVE_OVERWIEW or LEAVE_DETAIL
	 * @return	array	
	 */
	public function getSelectArray($leave)
	{
		if ($leave !== TE_CONST::LEAVE_OVERWIEW && $leave !== TE_CONST::LEAVE_DETAIL)
			$leave = TE_CONST::LEAVE_OVERWIEW;
		$arrSelect = array();
		foreach ($this->tableMeta[$leave] as $item)
		{
			//print_r($item);
			if ($item[TE_CONST::LEAVE_VIRTUAL] == false)
				$arrSelect[] = $item[TE_CONST::LEAVE_COLUMN];
		}
		return $arrSelect;
	}
	
	
	/**
	 * Returns leave 'overview' from meta-config
	 *
	 * @access	public
	 * @return	array	
	 */
	public function getOverviewMeta()
	{
		return $this->tableMeta[TE_CONST::LEAVE_OVERWIEW];
	}
	
	/**
	 * Returns leave 'detail' from meta-config
	 *
	 * @access	public
	 * @return	array	
	 */
	public function getDetailMeta()
	{
		return $this->tableMeta[TE_CONST::LEAVE_DETAIL];
	}
	
	/**
	 * Returns the table's name
	 *
	 * @access	public
	 * @return	string	
	 */
	public function getTableName()
	{
		return $this->tableName;
	}
	
	/**
	 * Returns the table's label if defined in the meta-config (optional); Otherwise table's name is returned
	 *
	 * @access	public
	 * @return	string	
	 */
	public function getTableLabel()
	{
		return $this->tableMeta[TE_CONST::LEAVE_LABEL];
	}
	
	
	/**
	 * Returns the table's description if defined in the meta-config (optional); Otherwise empty string
	 *
	 * @access	public
	 * @return	string	
	 */
	public function getTableDescription()
	{
		return $this->tableMeta[TE_CONST::LEAVE_DESCR];
	}
	
	
	/**
	 * Method tells if it is allowed to add items to the table
	 *
	 * @access	public
	 * @return	bool	
	 */
	public function checkIsAddAllowed()
	{
		return $this->tableMeta[TE_CONST::LEAVE_ADD_ITEM];
	}
	/**
	 * Method tells if it is allowed to delete items from the table
	 *
	 * @access	public
	 * @return	bool	
	 */
	public function checkIsDeleteAllowed()
	{
		return $this->tableMeta[TE_CONST::LEAVE_DELETE_ITEM];
	}
	/**
	 * Method tells if the order-feature or manual sorting is enabled or not (leave 'order')
	 *
	 * @access	public
	 * @return	bool	
	 */
	public function checkIsManualOrderEnabled()
	{
		return $this->tableMeta[TE_CONST::LEAVE_ORDER_MANUAL];
	}
	
	/**
	 * Returns order string with sql-columns for ordering (leave 'orderBy')
	 *
	 * @access	public
	 * @return	string	
	 */
	public function getOrderBy()
	{
		return $this->tableMeta[TE_CONST::LEAVE_ORDER_BY];
	}
	
	/**
	 * Returns array containing column-names for search-form
	 *
	 * @access	public
	 * @return	array	Array contains the arrays with column and label
	 */
	public function getSearchItemArray()
	{
		$arrSearchCol = array();
		for ($i = 0; $i<count($this->tableMeta[TE_CONST::LEAVE_OVERWIEW]); $i++)
			if ($this->tableMeta[TE_CONST::LEAVE_OVERWIEW][$i][TE_CONST::LEAVE_SEARCH] == true)
				 $arrSearchCol[] = $this->tableMeta[TE_CONST::LEAVE_OVERWIEW][$i];
		return $arrSearchCol;
	}
	
	/**
	 * Method returns flag which indicates if one input-field is defined as 'file'
	 *
	 * @access	public
	 * @return	bool	
	 */
	public function isFileUpload()
	{
		return $this->isFileUpload;
	}
	
	/**
	 * Method returns hooks which shall be called before saving an item
	 *
	 * @access	public
	 * @return	array	
	 */
	public function getHooksPreSave()
	{
		return $this->arrHookPreSaveItem;
	}
	/**
	 * Method returns hooks which shall be called before deleting an item
	 *
	 * @access	public
	 * @return	array	
	 */
	public function getHooksPreDelete()
	{
		return $this->arrHookPreDeleteItem;
	}
	/**
	 * Method returns hooks which shall be called before the overview is rendered
	 *
	 * @access	public
	 * @return	array	
	 */
	public function getHooksPreRenderOverview()
	{
		return $this->arrHookPreRenderOverview;
	}
	
	
	/**
	 * Loads and validates the metadata, eventually translate language-depending fields, make sure mandatory nodes are available, and optional are set with default-values.
	 * This method throws exception TE_Exception if something is wrong in the config-file.
	 *
	 * @access	private
	 * @return	void	
	 */
	private function _loadMetadata()
	{
		$this->CI->config->load($this->configFilename, FALSE);
		$this->tableMeta = $this->CI->config->item('te_'.$this->tableName);
		if(! is_array($this->tableMeta) || count($this->tableMeta) == 0)
			throw new TE_Exception("Configuration-data for table te_{$this->tableName} do miss in the configuration-file {$this->configFilename}. Please define it first.", __METHOD__);
		
		if(!isset($this->tableMeta[TE_CONST::LEAVE_OVERWIEW]) || ! is_array($this->tableMeta[TE_CONST::LEAVE_OVERWIEW]) || count($this->tableMeta[TE_CONST::LEAVE_OVERWIEW]) == 0)
			throw new TE_Exception("The item 'overview' is missing for te_{$this->tableName} or contains no entries.", __METHOD__);
		if(!isset($this->tableMeta[TE_CONST::LEAVE_DETAIL]) || ! is_array($this->tableMeta[TE_CONST::LEAVE_DETAIL]) || count($this->tableMeta[TE_CONST::LEAVE_DETAIL]) == 0)
			throw new TE_Exception("The item 'detail' is missing for te_{$this->tableName} or contains no entries.", __METHOD__);
		
		// Check for hooks
		if(isset($this->tableMeta[TE_CONST::LEAVE_HOOK]) && ! is_array($this->tableMeta[TE_CONST::LEAVE_HOOK]) )
			throw new TE_Exception("The item 'hook' for te_{$this->tableName} needs to contain an string-array.", __METHOD__);
		else
			if(!isset($this->tableMeta[TE_CONST::LEAVE_HOOK]))
				$this->tableMeta[TE_CONST::LEAVE_HOOK] = array();
		$this->_loadHooks($this->tableMeta[TE_CONST::LEAVE_HOOK]);	
		
		// Make sure labe for tablename and description is set. Eventually use language-file.
		if ( !isset($this->tableMeta[TE_CONST::LEAVE_LABEL]) )
			$this->tableMeta[TE_CONST::LEAVE_LABEL] = $this->tableName;
		else
			$this->tableMeta[TE_CONST::LEAVE_LABEL] = $this->_translate_fieldname($this->tableMeta[TE_CONST::LEAVE_LABEL]);
		if ( !isset($this->tableMeta[TE_CONST::LEAVE_DESCR]) )
			$this->tableMeta[TE_CONST::LEAVE_DESCR] = '';
		$this->tableMeta[TE_CONST::LEAVE_DESCR] = $this->_translate_fieldname($this->tableMeta[TE_CONST::LEAVE_DESCR]);
		
		// Make sure that leaves addItem and deleteItem are set, otherwise set with default = true;
		if ( !isset($this->tableMeta[TE_CONST::LEAVE_ADD_ITEM]) || !is_bool($this->tableMeta[TE_CONST::LEAVE_ADD_ITEM]) )
			$this->tableMeta[TE_CONST::LEAVE_ADD_ITEM] = true;
		if ( !isset($this->tableMeta[TE_CONST::LEAVE_DELETE_ITEM]) || !is_bool($this->tableMeta[TE_CONST::LEAVE_DELETE_ITEM])  )
			$this->tableMeta[TE_CONST::LEAVE_DELETE_ITEM] = true;
		
		// Make sure order is defined
		if ( !isset($this->tableMeta[TE_CONST::LEAVE_ORDER_MANUAL]) || !is_bool($this->tableMeta[TE_CONST::LEAVE_ORDER_MANUAL]) )
			$this->tableMeta[TE_CONST::LEAVE_ORDER_MANUAL] = true;
		// Make sure orderBy is defined
		if ( !isset($this->tableMeta[TE_CONST::LEAVE_ORDER_BY]) || !is_string($this->tableMeta[TE_CONST::LEAVE_ORDER_BY]) )
			$this->tableMeta[TE_CONST::LEAVE_ORDER_BY] = '';
		else
			if (strlen($this->tableMeta[TE_CONST::LEAVE_ORDER_BY]) > 0)
				$this->tableMeta[TE_CONST::LEAVE_ORDER_MANUAL] = false;		// If orderBy is defined, manual order is disabled automatically
			
		
		// Eventually use language-file for labels ('lang:code_from_langFile');
		// Makes sure column is set (otherwise throws error). If label is not set, the name of column is taken...
		for ($i = 0; $i<count($this->tableMeta[TE_CONST::LEAVE_OVERWIEW]); $i++) {
			if (!isset($this->tableMeta[TE_CONST::LEAVE_OVERWIEW][$i][TE_CONST::LEAVE_COLUMN]))
				// Bang! 'column' is mandatory!
				throw new TE_Exception("Each entry in the node '".TE_CONST::LEAVE_OVERWIEW."' needs to have a node '".TE_CONST::LEAVE_COLUMN."'. At least one is missing for te_{$this->tableName}.", __METHOD__);
			if (!isset($this->tableMeta[TE_CONST::LEAVE_OVERWIEW][$i][TE_CONST::LEAVE_LABEL]))
				$this->tableMeta[TE_CONST::LEAVE_OVERWIEW][$i][TE_CONST::LEAVE_LABEL] = $this->tableMeta[TE_CONST::LEAVE_OVERWIEW][$i][TE_CONST::LEAVE_COLUMN];
			// Make sure that leave virtual is set, otherwise set with default = false;
			if ( !isset($this->tableMeta[TE_CONST::LEAVE_OVERWIEW][$i][TE_CONST::LEAVE_VIRTUAL]) || !is_bool($this->tableMeta[TE_CONST::LEAVE_OVERWIEW][$i][TE_CONST::LEAVE_VIRTUAL]) )
				$this->tableMeta[TE_CONST::LEAVE_OVERWIEW][$i][TE_CONST::LEAVE_VIRTUAL] = false;
			$this->tableMeta[TE_CONST::LEAVE_OVERWIEW][$i][TE_CONST::LEAVE_LABEL] = $this->_translate_fieldname($this->tableMeta[TE_CONST::LEAVE_OVERWIEW][$i][TE_CONST::LEAVE_LABEL]);
			// Make sure that leave search is set, otherwise set with default = false;
			if ( !isset($this->tableMeta[TE_CONST::LEAVE_OVERWIEW][$i][TE_CONST::LEAVE_SEARCH]) || !is_bool($this->tableMeta[TE_CONST::LEAVE_OVERWIEW][$i][TE_CONST::LEAVE_SEARCH]) )
				$this->tableMeta[TE_CONST::LEAVE_OVERWIEW][$i][TE_CONST::LEAVE_SEARCH] = false;
		}
		for ($i = 0; $i<count($this->tableMeta[TE_CONST::LEAVE_DETAIL]); $i++) {
			if (!isset($this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_COLUMN]))
				// Bang! 'column' is mandatory!
				throw new TE_Exception("Each entry in the node '".TE_CONST::LEAVE_DETAIL."' needs to have a node '".TE_CONST::LEAVE_COLUMN."'. At least one is missing for te_{$this->tableName}.", __METHOD__);
			if (!isset($this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_LABEL]))
				$this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_LABEL] = $this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_COLUMN];
			$this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_LABEL] = $this->_translate_fieldname($this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_LABEL]);
			// Init optional leaves if missing
			if ( !isset($this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_EDITABLE]) || !is_bool($this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_EDITABLE]) )
				$this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_EDITABLE] = true;
			if ( !isset($this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_UNIQUE]) || !is_bool($this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_UNIQUE]) )
				$this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_UNIQUE] = false;
			if ( !isset($this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_RULES]) || !is_string($this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_RULES]) )
				$this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_RULES] = '';
			if ( !isset($this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_INPUTTYPE]) || !is_string($this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_INPUTTYPE]) )
				$this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_INPUTTYPE] = '';
			else
				if ( $this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_INPUTTYPE] == "file" )
					$this->isFileUpload = true;
			if ( !isset($this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_DELETE_RESTR]) )
				$this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_DELETE_RESTR] = array();
			else
			{
				 if ( is_string($this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_DELETE_RESTR]) )
				 	$this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_DELETE_RESTR] = array($this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_DELETE_RESTR]);
			}
			if ( !isset($this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_VIRTUAL]) || !is_bool($this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_VIRTUAL]) )
				$this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_VIRTUAL] = false;

			//Does column point to a lookup-tables?
			$this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_FK_TABLE] = '';
			if ( isset($this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_FOREIGN_KEY]) && is_string($this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_FOREIGN_KEY]) )
			{
				$fk_string = $this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_FOREIGN_KEY];
				$arr = explode(",", $fk_string );
				$exMsg = "Node " . TE_CONST::LEAVE_FOREIGN_KEY . " for column " . $this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_COLUMN] . " is in wrong format. Correct format: 'TableName.KeyColumn,ValueColumn'";
				if(count($arr) != 2)
					throw new TE_Exception($exMsg, __METHOD__);
				$arr2 = explode(".", $arr[0]);
				if(count($arr2) != 2)
					throw new TE_Exception($exMsg, __METHOD__);
				
				$this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_FK_TABLE]		= $arr2[0];	// Tablename of lookup-table
				$this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_FK_KEY_COL]	= $arr2[1];	// Column with key in lookup-table
				$this->tableMeta[TE_CONST::LEAVE_DETAIL][$i][TE_CONST::LEAVE_FK_VAL_COL]	= $arr[1];	// Column with value in lookup-table

			}
		}
		
	}
	
	
	/**
	 * Takes the array with the hooks and places them into the correspondending hook-variables.
	 *
	 * @access	private
	 * @param	array	arrHooks	Array with the hooks
	 * @return	void	
	 */
	private function _loadHooks($arrHooks)
	{
		foreach($arrHooks as $key => $value)
		{
			if ($this->hookFileExistanceChecked === false)
			{
				// Make sure the file exists where the hook-methods need to be placed into
				$filePath = "application/libraries/tableeditor_hooks.php";
				if (!file_exists(BASEPATH . $filePath) )
					throw new TE_Exception("Since you have defined at least one hook, you need to create a file 'tableeditor_hooks.php' in '$filePath' where you would define the methods.", __METHOD__);
				$this->hookFileExistanceChecked = true;
			}
			
			if (is_string($value)) $value = array($value);		// A single hook could be given as string only, turn into array
			switch ($key) {
			    case TE_CONST::HOOK_PRE_SAVE_ITEM:
			        $this->arrHookPreSaveItem = $value;
			        break;
			    case TE_CONST::HOOK_PRE_DELETE_ITEM:
			        $this->arrHookPreDeleteItem = $value;
			        break;
			    case TE_CONST::HOOK_PRE_RENDER_OVERVIEW:
			        $this->arrHookPreRenderOverview = $value;
			        break;
			}

		}
	}
	
	
	/**
	 * Text which might be a lang-item which needs to be translated?
	 *
	 * @access	private
	 * @param	string	fieldname	Text which might be a lang-item which needs to be translated?
	 * @copyright Code comes one to one from CodeIgniter's form_validation - library
	 * @return	void	
	 */
	private function _translate_fieldname($fieldname)
	{
		// Do we need to translate the field name?
		// We look for the prefix lang: to determine this
		if (substr($fieldname, 0, 5) == 'lang:')
		{
			// Grab the variable
			$line = substr($fieldname, 5);			
			
			// Were we able to translate the field name?  If not we use $line
			if (FALSE === ($fieldname = $this->CI->lang->line($line)))
			{
				return $line;
			}
		}

		return $fieldname;
	}
	

}
// ******************************************** END CLASS TE_tableEditor_meta *********************************************



/**
 * This class implements the iterator and will make the class TE_tableEditor_meta traversable
 *
 * @package		TableEditor
 * @subpackage	Models
 * @category	Models
 * @author		Oliver Mischa Voegeli
 * @link		
 */
class MetaIterator implements Iterator {
    private $position = 0;
    private $meta;
    private $leave;
    const LEAVE_OVERWIEW = 1;
	const LEAVE_DETAIL = 2;


	/**
	 * Constructor
	 *
	 * According to parameter leave, it ask the overview or the detail - metadata from the meta-object
	 *
	 * @access	public
	 * @param	object TE_tableEditor_meta objMeta
	 * @param	constant Either self::OVERVIEW or self::DETAIL
	 */
    public function __construct(&$objMeta, $leave) {
        if ($leave !== self::LEAVE_OVERWIEW && $leave !== self::LEAVE_DETAIL)
			$leave = self::LEAVE_OVERWIEW;
		//$this->leave = $leave;
        $this->position = 0;
        if ($leave == self::LEAVE_DETAIL)
        	$this->meta =& $objMeta->getDetailMeta();
        else
        	$this->meta =& $objMeta->getOverviewMeta();
    }

	// Iterator-Interface
    function rewind() {
        $this->position = 0;
    }
	// Iterator-Interface
    function current() {
        return $this->meta[$this->position];
    }
	// Iterator-Interface
    function key() {
        return $this->position;
    }
	// Iterator-Interface
    function next() {
        ++$this->position;
    }
	// Iterator-Interface
    function valid() {
        return isset($this->meta[$this->position]);
    }
}


/**
 * Class contains constants which are used in different places among the table editor files
 */
class TE_CONST
{
	// Used in config tableEditor_metadata
	const LEAVE_OVERWIEW		= 'overview';
	const LEAVE_DETAIL			= 'detail';
	const LEAVE_DESCR			= 'description';
	const LEAVE_ADD_ITEM		= 'addItem';
	const LEAVE_DELETE_ITEM		= 'deleteItem';
	const LEAVE_ORDER_MANUAL	= 'order';
	const LEAVE_ORDER_BY		= 'orderBy';
	const LEAVE_LABEL			= 'label';
	const LEAVE_COLUMN			= 'column';
	const LEAVE_RULES			= 'rules';
	const LEAVE_SEARCH			= 'search';
	const LEAVE_EDITABLE		= 'editable';
	const LEAVE_INPUTTYPE		= 'inputType';
	const LEAVE_UNIQUE			= 'unique';
	const LEAVE_DELETE_RESTR	= 'delete_restrict';
	const LEAVE_FOREIGN_KEY		= 'foreignKey';
	const LEAVE_VIRTUAL			= 'virtual';
	const LEAVE_HOOK			= 'hook';
	
	// Only internal use
	const LEAVE_FK_TABLE		= 'fkTable';
	const LEAVE_FK_KEY_COL		= 'fkKeyCol';
	const LEAVE_FK_VAL_COL		= 'fkValCol';
	
	// Hook names
	const HOOK_PRE_SAVE_ITEM		= 'pre_saveItem';
	const HOOK_PRE_DELETE_ITEM		= 'pre_deleteItem';
	const HOOK_PRE_RENDER_OVERVIEW	= 'pre_renderOverview';
}


/**
 * Own Exception-classes: TE_Exception is thrown when an application-error occurs, e.g. missing nodes in tableEditor_metadata
 */
class TE_Exception extends Exception {
   
	function __construct($message, $method) {
		$this->message = "Application-Error: " . $message;
		log_message('error', "Exception thrown in ".__CLASS__."::".$method."(): $message");
	}
}
/**
 * TE_Exception_DB is thrown when something DB-related is wrong, e.g. value which is not unique, or delete-restriction
 */
class TE_Exception_DB extends Exception {
   
	function __construct($message) {
		$this->message = $message;
	}
}
/**
 * TE_Exception_hook should be thrown in libraries/tableeditor_hooks.php in case of errors
 * 
 * @param	string	message				This message is sent to the client's browser
 * @param	string	internalMessage		Internal message for logging, containing technical informations
 * @param	string	debugLevel			Debug-level, see $config['log_threshold'] in codeigniter's config-file
 */
class TE_Exception_hook extends Exception {
   
	function __construct($message, $internalMessage = '', $debugLevel = 'error') {
		$this->message = $message;
		log_message($debugLevel, "Hook-Exception thrown. Message shown to customer: $message. Internal message: $internalMessage");
	}
}
