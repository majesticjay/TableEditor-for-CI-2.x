<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
 * Created on 30.12.2009
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */

/**
 * In order to avoid name-conflicts with other config-items, ALWAYS ADD 'te_' as a prefix before the tablename!
 * 
 * Possible optional config for leave ['label']: Here you can define another title instead of the table's name. Possible prefix: 'lang:' --> define it in language-file
 * Possible optional config for leave ['description']: A description of the table can be defined here. Possible prefix: 'lang:' --> define it in language-file
 * Possible optional config for leave ['addItem']: If set to false, no new items can be added to the table. Default: true
 * Possible optional config for leave ['deleteItem']: If set to false, no items can be deleted from the table. Default: true
 * Possible optional config for leave ['order']: If set to false, the manual order-feature is disabled. In that case, items can't be moved up or down. Default: true (unless leave 'orderBy' is set)
 * Possible optional config for leave ['orderBy']: Define one or several columns (string, comma-separated) how the overview shall be sorted. This sets the leave 'order' automatically to false
 * Possible optional config for leave ['hook']: Takes an array with hooks: 'pre_saveItem', 'pre_deleteItem'
 * Possible optional config for leave ['overview'][]['search']: true / false  (default: false); if true, this field is searchable
 * Possible optional config for leave ['detail'][]['editable']: true / false  (default: true); if false, this column is only shown and won't be editable
 * Possible optional config for leave ['detail'][]['inputType']: checkbox / textarea / file (default: input)
 * Possible optional config for leave ['detail'][]['rules']: Same rules as in CI's form_validation-library.
 * Possible optional config for leave ['detail'][]['unique']: Default false. If true, system will check for uniqueness in the table.
 * Possible optional config for leave ['detail'][]['delete_restrict']: Array or string: 'Tablename'.'Column': When an item is deleted, it is first checked if it exists in the given table's column.
 * 		If yes, deletion is not possible.
 * Possible optional config for leave ['detail'][]['foreignKey']: Defines the column as foreign-key and hooks up a lookuptable according to following string-definition: 'LookupTablename.KeyColumn,ValueColumn'
 * Possible optional config for leave ['detail'][]['virtual']: If set to true, the correspondending column as defined in the leave 'column' is not loaded from the DB, handy for hooks. Default: false 
 */
$config = array(

		///// Table Country
		'te_Country' => array(
			
			'label'			=> 'Administration Countries',	// Optional
			'description'	=> 'Here you can administrate your countries.',	// Optional
			
			'overview'	=> array(
									array(
											'label'		=> 'Countrycode',
											'column'	=> 'Code'
										),
									array(
											'label'		=> 'Description',
											'column'	=> 'Description'
										),
								
								),


			'detail'	=> array(
									array(
											'label'		=> 'Create-Date',
											'column'	=> 'HdCreateDate',
											'editable'	=> false,
										),
									array(
											'label'				=> 'Countrycode (CH, DE etc.)*',
											'column'			=> 'Code',
											'rules'				=> 'trim|required|max_length[2]',
											'unique'			=> true,
											'delete_restrict'	=> array('User.Country'),
										),
									array(
											'label'		=> 'Description*',
											'column'	=> 'Description',
											'rules'		=> 'trim|required|max_length[64]',
										),
								
								),
		),
		
	
		///// Table User
		'te_User' => array(
			
			'label'			=> 'Administration User',	// Optional
			'description'	=> 'Here you can administrate your users.',	// Optional
			
			'overview'	=> array(
									array(
											'label'		=> 'Name of User',
											'column'	=> 'Name',
											'search'	=> true
										),
									array(
											'label'		=> 'Age',
											'column'	=> 'Age',
											'search'	=> true
										),
									array(
											'label'		=> 'Countrycode',
											'column'	=> 'Country',
											'search'	=> true
										),
								
								),


			'detail'	=> array(
									array(
											'label'		=> 'Create-Date',
											'column'	=> 'HdCreateDate',
											'editable'	=> false,
										),
									array(
											'label'		=> 'Name of User*',
											'column'	=> 'Name',
											'rules'		=> 'trim|required|max_length[64]',
										),
									array(
											'label'		=> 'Age*',
											'column'	=> 'Age',
											'rules'		=> 'required|integer',
										),
									array(
											'label'				=> 'Countrycode',
											'column'			=> 'Country',
											'rules'				=> 'trim|required|max_length[2]',
											'foreignKey'		=> 'Country.Code,Description',
											//'delete_restrict'	=> array('SomeOtherTable.ForeignKey'),	// Delete restrict, optional
										),

								
								),
		),
		
		
		///// Table Document
		'te_Document' => array(
			
			'label'			=> 'Administration Documents',	// Optional
			'description'	=> 'Here you can administrate your documents.',	// Optional
			'orderBy'		=> 'Name',													// Optional, overwrites node 'order'!
			
			'hook'			=> array(
									 'pre_saveItem'			=> 'doc_beforeSave',		// Hook is called before the item is saved to the DB
									 'pre_deleteItem'		=> 'doc_beforeDelete',		// Hook is called before the item is deleted from the DB
									 'pre_renderOverview'	=> 'doc_overview',			// Hook is called before the labels and their data are passed to the view
									),
								
			'overview'	=> array(
									array(
											'label'		=> 'Description',
											'column'	=> 'Name',
										),
									array(
											'label'		=> 'Name of document',
											'column'	=> 'Filename'
										),
									array(
											'label'		=> 'Document on Server',
											'column'	=> 'DocOnServer',
											'virtual'	=> true,							// No correspondending column exists in DB for 'DocOnServer', makes it handy for hooks
										),
								),

			'detail'	=> array(
									array(
											'label'		=> 'Create-Date',
											'column'	=> 'HdCreateDate',
											'editable'	=> false,
										),
									array(
											'label'		=> 'Description*',
											'column'	=> 'Name',
											'rules'		=> 'trim|required|max_length[64]',
										),
									array(
											'label'		=> 'Filename',
											'column'	=> 'Filename',
											'editable'	=> false,
										),
									array(
											'label'		=> 'Browse your file to upload',
											'column'	=> 'Filedata',
											'inputType'	=> 'file',							// This will result in an html-upload input field
											'virtual'	=> true,							// No correspondending column exists in DB for 'Filedata', makes it handy for hooks
										),
								
								),
		),


);



