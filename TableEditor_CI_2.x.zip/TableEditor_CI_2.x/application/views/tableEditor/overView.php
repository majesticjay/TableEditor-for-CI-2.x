<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>TableEditor :: <?php echo $title ?></title>
		<link href="<?php echo base_url();?>css/te_stylesheet.css" rel="stylesheet" type="text/css" />
	</head>
	
	<body>
	<div class="te_wrapper">
<?php
	echo "<h3>".htmlspecialchars($title)."</h3>";
	if (isset($msg) && strlen($msg) > 0) echo '<p class="te_msg">' . $msg . "</p>\n";	/* If msg was submitted, show it */
	echo '<p class="tableDescr">' . $objMeta->getTableDescription() . "</p>";
	
	// Build search-form (if search-column have been defined)
	echo getSearchForm($this, $objMeta, $itemSearchURI, $arrSearchData);
	
	if ($objMeta->checkIsAddAllowed() == true)
		echo anchor($itemNewURI, '» ' . $this->lang->line('te_title_newItem')); 
?>
<table class="data">
<tr class="odd">
	<th><?php echo $this->lang->line('te_title_description'); ?></th>
	<th class="function"><?php echo $this->lang->line('te_title_function'); ?></th>
</tr>
<?php
$i = 0;
$itemCount = $objTable->num_rows();
foreach ($objTable->result() as $row)
{
	if ($i % 2 == 0)
		echo "<tr>\n";
	else
		echo '<tr class="odd">'."\n";
	
	$content = '';
	foreach($objOverviewIterator as $itemMeta) {
		$label = htmlspecialchars($itemMeta[TE_CONST::LEAVE_LABEL]);
		if (strlen($label) > 0) $content .= $label . ": ";
		if ($htmlEscapeData)
			$data = htmlspecialchars($row->$itemMeta[TE_CONST::LEAVE_COLUMN]);
		else
			$data = $row->$itemMeta[TE_CONST::LEAVE_COLUMN];
		$content .= $data . "<br />";
	}
	echo "<td>" . $content . "</td>\n";
	echo "<td>";
	if ($objMeta->checkIsManualOrderEnabled() && $i > 0)
		echo anchor($controllerPath . '/itemMove/' . $tableName . '/' . $row->Id . '/up', $this->lang->line('te_title_up') ) . "<br />";
	echo anchor($controllerPath . '/itemEdit/' . $tableName . '/' . $row->Id, $this->lang->line('te_title_edit') ) . "<br />";
	if ($objMeta->checkIsDeleteAllowed() == true)
		echo anchor($controllerPath . '/itemDelete/' . $tableName . '/' . $row->Id, $this->lang->line('te_title_delete')) . "<br />";
	if ($objMeta->checkIsManualOrderEnabled() && $i < $itemCount - 1)
		echo anchor($controllerPath . '/itemMove/' . $tableName . '/' . $row->Id . '/down', $this->lang->line('te_title_down') ) . "<br />";
	echo "</td>\n";
	echo "</tr>\n";
	$i++;
}
?>
</table>
</div>
</body>
</html>



<?php
/**
 * Generates the search-form
 * 
 * @param object		objMeta			Contains the meta-data
 * @param string		searchURI		Contains URI for search-method
 * @param array			arrSearchData	Contains column/value - pairs from the filled in search-values
 * @return string
 */
function getSearchForm($CI, $objMeta, $searchURI, $arrSearchData)
{
	//die("ydsf");
	$arrSearchItem = $objMeta->getSearchItemArray();
	if (count($arrSearchItem) == 0) return '';		// No searchfields defined
	
	$html = form_open($searchURI);
	$html .= nl2br(htmlspecialchars($CI->lang->line('te_txt_search')));
	$html .= '<table class="te_search">' . "\n";
	$html .= '<tr>' . "\n";
	$html .= '	<th>' . $CI->lang->line('te_title_field') . "</th>\n";
	$html .= '	<th>' . $CI->lang->line('te_title_searchValue') . "</th>\n";
	$html .= "</tr>\n";

	foreach($arrSearchItem as $searchItem)
	{
		$value = '';
		if (isset($arrSearchData[$searchItem[TE_CONST::LEAVE_COLUMN]]))
			$value = $arrSearchData[$searchItem[TE_CONST::LEAVE_COLUMN]];
		$html .= '	<tr><td>' . $searchItem[TE_CONST::LEAVE_LABEL] . '</td><td>' . form_input($searchItem[TE_CONST::LEAVE_COLUMN], $value) . "</td></tr>\n";
	}
	
	$html .= "</table>\n";
	$html .= form_submit('searchItem', $CI->lang->line('te_title_search') ) . form_close() . "<br />\n";
	
	return $html;
	
	/*if (strlen($meta['fkTable']) > 0)
	{
		$lookupArr = $CI->mdl_tableEditor->getLookupTable($meta['fkTable'], $meta['fkKeyCol'], $meta['fkValCol']);
		return form_dropdown($meta['column'], $lookupArr, $data);
		//return $meta['fkTable'];
	}
	
	switch (strtolower($meta['inputType'])) {
	    case 'checkbox':
	        return form_checkbox('', $meta['column'], (bool)$data);
	    case 'textarea':
	        return form_textarea($meta['column'], htmlspecialchars($data), 'class="big"');
	    case 'file':
	        return form_upload($meta['column'], htmlspecialchars($data));
	}
	return form_input($meta['column'], htmlspecialchars($data));*/
}



?>