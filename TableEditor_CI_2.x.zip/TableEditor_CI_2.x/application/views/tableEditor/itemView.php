<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>TableEditor :: <?php echo $title ?></title>
		<link href="<?php echo base_url();?>css/te_stylesheet.css" rel="stylesheet" type="text/css" />
	</head>
	
	<body>
	<div class="te_wrapper">
<?php
/*
 * Created on 30.12.2009
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */

echo "<h3>".htmlspecialchars($title)."</h3>";
if (isset($msg) && strlen($msg) > 0) echo '<p class="te_msg">' . $msg . "</p>\n";	/* If msg was submitted, show it */
echo '<div class="validationError" style="color: red;">' . validation_errors() . '</div>';
if ($isFileUpload)
	echo form_open_multipart($itemSaveURI);
else
	echo form_open($itemSaveURI);
?>

<table class="data">
<tr class="odd">
	<th><?php echo $this->lang->line('te_title_description'); ?></th>
	<th><?php echo $this->lang->line('te_title_value'); ?></th>
</tr>
<?php
$i = 0;
foreach($objDetailIterator as $itemMeta) {
	if ($i % 2 == 0)
		echo "<tr>\n";
	else
		echo '<tr class="odd">'."\n";
	
	$formValData = set_value($itemMeta[TE_CONST::LEAVE_COLUMN]);
	if (isset($objData) && strLen($formValData) == 0 && $itemMeta[TE_CONST::LEAVE_VIRTUAL] == false)
		$data = $objData->$itemMeta[TE_CONST::LEAVE_COLUMN];
	else
		$data = $formValData;
	
	($itemMeta[TE_CONST::LEAVE_UNIQUE] == false) ? $unique = '' : $unique = ' (' . $this->lang->line('te_title_unique') . ')';
	
	echo "<td>" . htmlspecialchars($itemMeta[TE_CONST::LEAVE_LABEL]) . "$unique</td><td>" . getHtmlInputElement($this, $itemMeta, $data) . "</td>\n";
	
	echo "</tr>\n";
	$i++;
}
?>
</table>
<br />
<?php echo form_submit('saveItem', $this->lang->line('te_title_save') ) . form_close();
echo form_open($controllerPath . '/itemOverview/' . $tableName) . form_submit('cancel', $this->lang->line('te_title_cancel') ) . form_close(); ?>
</div>
</body>
</html>

<?php
/**
 * Generates the html-input-element according to the leave 'inputType'. If 'inputType' is not set, default is a html-input.
 * If 'editable' is set to false, no html-input is generated and the plain text is returned.
 * 
 * @param array		meta	Contains the metadata of the column
 * @param string	data	Data which is contained in the column
 * @return string
 */
function getHtmlInputElement($CI, $meta, $data)
{
	if ($meta[TE_CONST::LEAVE_EDITABLE] == false )
		return htmlspecialchars($data);
	
	if (strlen($meta[TE_CONST::LEAVE_FK_TABLE]) > 0)
	{
		$lookupArr = $CI->mdl_tableEditor->getLookupTable($meta[TE_CONST::LEAVE_FK_TABLE], $meta[TE_CONST::LEAVE_FK_KEY_COL], $meta[TE_CONST::LEAVE_FK_VAL_COL]);
		return form_dropdown($meta['column'], $lookupArr, $data);
		//return $meta['fkTable'];
	}
	
	switch (strtolower($meta[TE_CONST::LEAVE_INPUTTYPE])) {
	    case 'checkbox':
	        return form_checkbox('', $meta[TE_CONST::LEAVE_COLUMN], (bool)$data);
	    case 'textarea':
	        return form_textarea($meta[TE_CONST::LEAVE_COLUMN], htmlspecialchars($data), 'class="big"');
	    case 'file':
	        return form_upload($meta[TE_CONST::LEAVE_COLUMN], htmlspecialchars($data));
	}
	return form_input($meta[TE_CONST::LEAVE_COLUMN], htmlspecialchars($data));
}



?>
