<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
 * Created on 30.12.2009
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */


/**
 * TableEditor's Controller Class
 *
 * @package		TableEditor
 * @subpackage	Controllers
 * @category	Controllers
 * @author		Oliver Mischa Voegeli
 * @version		0.3
 * @link		
 */
class tableEditor extends CI_Controller {

	private $controllerPath	= '';
	private $tableName		= '';
	private $objMeta;									// Instance of Class TE_tableEditor_meta (file models/mdl_tableeditor.php), containing meta-data from config-file
	private $viewPath		= 'tableEditor/';			// Path to the files containing tableEditor's views
	private $language		= 'english';				// You could provide other language-files in the directory application/language
	private $arrSearchData	= array();					// Contains column/value - pairs of search-form
	
	
	function __construct()
	{
		parent::__construct();
		
		//*************************** ACCESS - RIGHTS *********************************************
		// You might insert here access-rights. Or you could inherit from your own controller.
		// Or you might wan't to use a hook. It's up to you, how you will protect your DB!
		//*****************************************************************************************
		
		$this->controllerPath	= __CLASS__;			// Adjust path to your own needs
		$this->lang->load('tableEditor', $this->language);
		$this->load->model('mdl_tableEditor', '', true);
		$this->load->helper(array('form', 'url'));
		$this->load->library(array('session','validation'));
		
	}
	
	
	/**
	 * Index function, calls itemOverview which will lead to an error since no tablename has been passed.
	 *
	 * @access	public
	 * @return	void	
	 */
	function index()
	{
		$this->itemOverview('');
	}
	
	
	function itemSearch($tableName = '')
	{
		if ( !$this->_init($tableName) ) return;
		
		$arrSearchItemMeta = $this->objMeta->getSearchItemArray();
		$arrSearchItem = array();
		foreach($arrSearchItemMeta as $searchItem)
		{
			$searchValue = trim($this->input->post($searchItem[TE_CONST::LEAVE_COLUMN]));
			if (strlen($searchValue) > 0)
				$arrSearchItem[$searchItem[TE_CONST::LEAVE_COLUMN]] = $searchValue;
		}
		$this->arrSearchData = $arrSearchItem;
		$this->mdl_tableEditor->setSearchItem($arrSearchItem);
		$this->itemOverview();
	}
	
	
	/**
	 * Lists the table's content in the overview
	 *
	 * @access	public
	 * @param	string	Expects the database's tablename which shall be displayed
	 * @return	void	
	 */
	function itemOverview($tableName = '', $msg = '')
	{

		if ( !$this->_init($tableName) ) return;
		
		$data['msg']		= trim($msg . " " . $this->session->flashdata('msg'));
		$data['itemNewURI']	= $this->controllerPath . "/itemEdit/" . $this->tableName . "/";
		try {
			$data['objTable']	= $this->mdl_tableEditor->getTableOverview();
		}
		catch (TE_Exception_hook $ex)
		{
			// Something wen't wrong within a hook
			$data['msg'] .= " " . $ex->getMessage();
		}
		catch (TE_Exception $ex)
		{
			die(htmlspecialchars($ex->getMessage()));
		}
		$htmlEscapeData = true;
		if ( count($this->objMeta->getHooksPreRenderOverview() > 0) )
			$htmlEscapeData = false;					// There are hooks, which means view won't do anymore any html escaping on the data-field
		$data['itemSearchURI']			= $this->controllerPath . "/itemSearch/" . $this->tableName;
		$data['htmlEscapeData']			= $htmlEscapeData;
		$data['objMeta']				= $this->objMeta;
		$data['arrSearchData']			= $this->arrSearchData;
		$data['objOverviewIterator']	= new MetaIterator($this->objMeta, MetaIterator::LEAVE_OVERWIEW);	// Create Iterator for overview
		$this->_loadView("overView", $data);
	}
	
	
	/**
	 * Shows an item for editing
	 *
	 * @access	public
	 * @param	string	Expects the database's tablename which shall be displayed
	 * @param	string	Expects the table's Id of the item (table.Id) which shall be desplayed.
	 * @return	void	
	 */
	function itemEdit($tableName = '', $id = false, $msg = '')
	{
		if ( !$this->_init($tableName) ) return;
		if ($this->objMeta->checkIsAddAllowed() == false && $id === false)
		{
			// Sorry, it is not allowed to add new items to the table
			$this->session->set_flashdata('msg', $this->lang->line('te_msg_addItemNotAllowed'));
			redirect($this->controllerPath . "/itemOverview/" . $this->tableName);
			return;
		}
		
		if ($id !== false)
		{
			$objItem = $this->mdl_tableEditor->getItemById($this->objMeta->getTableName(), $id);
			if ($objItem->num_rows() < 1)
			{
				$data['msg'] = sprintf($this->lang->line('te_err_noItemFound'), $id, $tableName);
				$this->_loadView("errorView", $data);
				return;
			}
			$data['objData'] = $objItem->row_object();
		}
		
		/*$data['msg']		= $this->session->flashdata('msg');
		if (strlen($msg) > 0) $data['msg'] .= ' ' . $msg;*/
		$data['msg']		= trim($msg . " " . $this->session->flashdata('msg'));
		$data['itemSaveURI']	= $this->controllerPath . "/itemSave/" . $this->tableName . "/" . $id;
		$data['objDetailIterator']	= new MetaIterator($this->objMeta, MetaIterator::LEAVE_DETAIL);	// Create Iterator for details
		$data['isFileUpload']		= $this->objMeta->isFileUpload();
		$this->_loadView("itemView", $data);
	}
	
	
	/**
	 * Saves or adds an item to a table.
	 *
	 * @access	public
	 * @param	string	Expects the database's tablename which to where the item shall be saved.
	 * @param	string	Expects the table's Id of the item (table.Id) which shall be saved. If false, new entry will be generated
	 * @return	void	
	 */
	function itemSave($tableName = '', $id = false)
	{
		if ( !$this->_init($tableName) ) return;
		if ($this->objMeta->checkIsAddAllowed() == false && $id === false)
		{
			// Sorry, it is not allowed to add new items to the table
			$this->session->set_flashdata('msg', $this->lang->line('te_msg_addItemNotAllowed'));
			redirect($this->controllerPath . "/itemOverview/" . $this->tableName);
			return;
		}
		
		$this->load->library('form_validation');
		
		$objDetailIterator = new MetaIterator($this->objMeta, MetaIterator::LEAVE_DETAIL);
		$data = array();
		foreach($objDetailIterator as $itemMeta)
		{
			// Gather columns and their data for saving...
			if ( $itemMeta[TE_CONST::LEAVE_EDITABLE] == false || $itemMeta[TE_CONST::LEAVE_VIRTUAL] == true)
				continue;		// Column is not editable or virtual (aka not existing in DB), skip it
			
			// Form-Validation-Magic: if rules have been defined, add it - otherwise add empty rules
			$rules = $itemMeta[TE_CONST::LEAVE_RULES];
			$this->form_validation->set_rules($itemMeta[TE_CONST::LEAVE_COLUMN], $itemMeta[TE_CONST::LEAVE_LABEL], $rules);

			$data[$itemMeta[TE_CONST::LEAVE_COLUMN]] = $this->input->post($itemMeta[TE_CONST::LEAVE_COLUMN]);
		}
		
		if ($this->form_validation->run() == FALSE) {
			$this->itemEdit($this->tableName, $id);		// Form-validation failed
			return;
		}
		
		// Save / Add item
		try
		{
			$boolSave = $this->mdl_tableEditor->itemSave($id, $data);
		}
		catch (TE_Exception_DB $ex)
		{
			// Something wen't wrong while saving to DB
			$this->itemEdit($this->tableName, $id, $ex->getMessage());
			return;
		}
		catch (TE_Exception_hook $ex)
		{
			// Something wen't wrong within a hook
			$this->itemEdit($this->tableName, $id, $ex->getMessage());
			return;
		}
		catch (TE_Exception $ex)
		{
			die(htmlspecialchars($ex->getMessage()));
		}
			
		if ($boolSave == true)
		{
			if ($id === false)
				$this->session->set_flashdata('msg', $this->lang->line('te_msg_itemCreated') );
			else
				$this->session->set_flashdata('msg', $this->lang->line('te_msg_itemSaved') );
			redirect($this->controllerPath . "/itemOverview/" . $this->tableName);
		} else
		{
			//TODO: Error occured
		}
		
	}
	
	
	/**
	 * Deletes an item from a table
	 *
	 * @access	public
	 * @param	string	Expects the database's tablename from where the item shall be deleted.
	 * @param	string	Expects the table's Id of the item (table.Id) which shall be deleted.
	 * @return	void	
	 */
	function itemDelete($tableName = '', $id = false)
	{
		if ( !$this->_init($tableName) ) return;
		if ($this->objMeta->checkIsDeleteAllowed() == false)
		{
			// Sorry, it is not allowed to delete an item from the table
			$this->session->set_flashdata('msg', $this->lang->line('te_msg_deleteItemNotAllowed'));
			redirect($this->controllerPath . "/itemOverview/" . $this->tableName);
			return;
		}
		
		try
		{
			$this->mdl_tableEditor->itemDelete($id);
		}
		catch (TE_Exception_DB $ex)
		{
			// Something went wrong while deleting
			$this->itemOverview($this->tableName, $ex->getMessage());
			return;
		} catch (TableEditorException $e) {
        	die($e->getMessage());
		} catch (Exception $e) {
        	die($e->getMessage());
		}
		
		$this->session->set_flashdata('msg', $this->lang->line('te_msg_itemDeleted') );
		redirect($this->controllerPath . "/itemOverview/" . $this->tableName);
	}
	
	
	/**
	 * Moves an item up or down, depending on direction
	 *
	 * @access	public
	 * @param	string	$tableName	Table's name
	 * @param	string	$id			Id of item
	 * @param	string	$direction	Direction: 'up' or 'down'
	 * @return	void	
	 */
	function itemMove($tableName = '', $id = false, $direction = 'up')
	{
		if ( !$this->_init($tableName) ) return;
		if ($id === false) {
			$this->itemOverview($tableName);
			return;
		}
		$this->mdl_tableEditor->itemMove($id, $direction);
		$this->itemOverview($tableName);
	}
	
	
	
	/**
	 * Initial procedure: Validation tablename, loading metadata
	 *
	 * @access	private
	 * @param	string		Expects the database's tablename which shall be checked
	 * @return	boolean		If false, a view was already loaded, no further action needed	
	 */
	private function _init($tableName)
	{
		if ($this->objMeta != null)
			return true;			// Function was already called
		$this->tableName = $tableName;
		if (strlen($this->tableName) == 0)
		{
			$data['msg'] = $this->lang->line('te_err_noTableName');
			$this->_loadView("errorView", $data);
			return false;
		}
			
		if (!$this->mdl_tableEditor->tableExists($this->tableName))
		{
			$data['msg'] = sprintf($this->lang->line('te_err_tableDoesntExist'), $this->tableName);
			$this->_loadView("errorView", $data);
			return false;
		}

		try {
			$this->objMeta = new TE_tableEditor_meta($tableName);
		} catch (TableEditorException $e) {
        	die(htmlspecialchars($e->getMessage()));					// Some serious stuff, most probably error in meta-config file
		} catch (Exception $e) {
        	die(htmlspecialchars($e->getMessage()));
		}
		$this->mdl_tableEditor->setObjMeta($this->objMeta);
		//$this->mdl_tableEditor->setObjController($this);
		return true;
	}
	
	
	/**
	 * Loads the view. In case of different view-systems, e.g. partial view, adjustments are in here encapsulated
	 *
	 * @access	protected
	 * @param	string		Name of the view which shall be loaded
	 * @param	array		Mixed, containing the data which shall be passed to the view
	 * @return	void	
	 */
	protected function _loadView($viewName, $arrData)
	{
		($this->objMeta !== null) ? $arrData['title'] = $this->objMeta->getTableLabel() : $arrData['title'] = '';
		$arrData['controllerPath']	= $this->controllerPath;
		$arrData['tableName']		= $this->tableName;
		
		// ************************ This part might need to be adjusted depending on the view-system *******
		$this->load->view($this->viewPath . "/" . $viewName, $arrData);
		// *************************************************************************************************
	}
	

	
}


