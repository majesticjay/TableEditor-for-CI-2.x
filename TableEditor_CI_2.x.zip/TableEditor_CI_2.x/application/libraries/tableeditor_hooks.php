<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/*
 * Created on 05.02.2010
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
 

class Tableeditor_hooks {

	private $CI;
	
    public function __construct()
    {
		$this->CI =& get_instance();
    }


	/**
	 * Hook is called before the item of the table documentation is saved. It uploads the selected file.
	 * 
	 * $newData contains all data which will be saved to the DB. It needs to be passed by reference (&), otherwise manipulations won't have any effect!
	 * $oldData contains the complete item-row of the table with the old data (or empty, if new entry)
	 */
	public function doc_beforeSave(&$newData, $oldData)
	{
		
		if(!isset($_FILES['Filedata']) || trim($_FILES['Filedata']['name']) == '')
			return;	// No File has been selected, upload nothing
		
		$uploadDir = 'upload/';		// You might want to load this from a config-file instead
		// Upload file. For more information, see CI's Upload class.
		$config['upload_path']		= $uploadDir;	// Upload-directory
		$config['allowed_types']	= 'pdf';		// Allow only pdf
		$config['max_size']			= '2000';		// Max. size
		
		$this->CI->load->library('upload', $config);
		
		$_FILES['Filedata']['name'] = time() . ".pdf";		// Give the file an unique name
		$newData['Filename'] = $_FILES['Filedata']['name'];	// Save the file's name into the DB-field 'Filename'
		
		if ( !$this->CI->upload->do_upload('Filedata') )
			throw new TE_Exception_hook( $this->CI->upload->display_errors('', '') );	// Something went wrong in CI's upload class, show error
		
		// We check in the old data if there is an old file around, and if yes, delete it
		if(isset($oldData['Filename']) && strlen($oldData['Filename']) > 0)
		{
			$relFilePath = $uploadDir . $oldData['Filename'];
			if (file_exists($relFilePath) )
				unlink($relFilePath);
		}
	}
	

	/**
	 * Hook is called before the item of the table documentation is deleted. Any linked file would be deleted as well from the upload-directory.
	 * 
	 * $data contains the complete item-row of the table which is about to be deleted.
	 */
	public function doc_beforeDelete($data)
	{
		$uploadDir = 'upload/';		// You might want to load this from a config-file instead
		// We check in the old data if there is an old file around, and if yes, delete it
		if( strlen($data['Filename']) > 0 )
		{
			$relFilePath = $uploadDir . $data['Filename'];
			if (file_exists($relFilePath) )
				unlink($relFilePath);
		}
	}
	
	
	/**
	 * Hook is called before the list is rendered to the overview. It is called for each single overview-item as defined under meta-data, and each row in the table
	 * 
	 * $columnName	Column's name
	 * $columnData	Contains the data of the column (by reference!) which can be changed within the hook
	 * $rowData		Contains the fields from the DB.
	 */
	public function doc_overview($columnName, &$columnData, $rowData)
	{
		$columnData = htmlspecialchars($columnData);	// Don't forget to do this: as soon as you use a pre_renderOverview-hook, you are responsible to escape special html-chars!
		$uploadDir = 'upload/';		// You might want to load this from a config-file instead
		switch ($columnName) {
			case 'DocOnServer':				// Remember? We declared this column as virtual in the metadata, now we will fill its data with some value...
				$relFilePath = $uploadDir . $rowData->Filename;
				(file_exists($relFilePath) && strlen($rowData->Filename > 0) ) ? $columnData = "<b style=\"color:green\">yes</b>" : $columnData = "<b style=\"color:red\">no</b>";
				break;
			case 'Filename':				// We insert here a link to the file
				$absFilePath = base_url() . $uploadDir . $rowData->Filename;
				$columnData = '<a href="'.$absFilePath.'" target="_blank">' . $columnData . "</a>";
				break;
		}
	}
	
}

