<?php
/*
 * Created on 01.01.2010
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */

	// Errors
	$lang['te_err_noTableName']			= "Es wurde kein Tabellenname angegeben.";
	$lang['te_err_tableDoesntExist']	= "Tabelle %s existiert nicht in der Datenbank.";
	$lang['te_err_noItemFound']			= "Für die Id %s konnte in der Tabelle %s keinen Eintrag gefunden werden.";

	// Messages
	$lang['te_msg_itemCreated']				= "Der Eintrag wurde hinzugefügt.";
	$lang['te_msg_itemSaved']				= "Der Eintrag wurde gespeichert.";
	$lang['te_msg_itemDeleted']				= "Der Eintrag wurde gelöscht.";
	$lang['te_msg_addItemNotAllowed']		= "Es ist Ihnen nicht erlaubt, einen neuen Eintrag zu erfassen.";
	$lang['te_msg_deleteItemNotAllowed']	= "Es ist Ihnen nicht erlaubt, einen Eintrag zu löschen.";
	$lang['te_msg_valueNotUnique']			= "Das Feld %s muss mit einem einzigartigen Wert befüllt werden. Der Wert %s kommt bereits vor.";
	$lang['te_msg_deleteRestrict']			= "Der Eintrag kann nicht gelöscht werden, da das Feld %s bereits von der Tabelle %s referenziert wird.";
	
	// Texts
	$lang['te_txt_search']				= "Sie können Wildcards für die Suche benutzen.\nBenutzen Sie * für eine beliebige Anzahl von Zeichen, z.Bsp. '*vanni'.\nBenutzen Sie ? für ein unbekanntes Zeichen, z.Bsp. 'P?ter'.\nBenutzen Sie ... für numerische Bereiche, z.Bsp. '12...34'.";
	
	// Titles
	$lang['te_title_description']		= "Bezeichnung";
	$lang['te_title_value']				= "Wert";
	$lang['te_title_function']			= "Funktion";
	$lang['te_title_save']				= "Speichern";
	$lang['te_title_cancel']			= "Abbrechen";
	$lang['te_title_edit']				= "Editieren";
	$lang['te_title_delete']			= "Löschen";
	$lang['te_title_newItem']			= "Neuen Eintrag erfassen";
	$lang['te_title_up']				= "Hoch";
	$lang['te_title_down']				= "Runter";
	$lang['te_title_unique']			= "Einzigartig";
	$lang['te_title_field']				= "Feld";
	$lang['te_title_searchValue']		= "Suchwert";
	$lang['te_title_search']			= "Suche";
	

?>
