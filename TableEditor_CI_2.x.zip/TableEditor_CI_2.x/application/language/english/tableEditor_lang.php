<?php
/*
 * Created on 01.01.2010
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */

	// Errors
	$lang['te_err_noTableName']			= "No table-name has been defined.";
	$lang['te_err_tableDoesntExist']	= "Table %s does not exist in the database.";
	$lang['te_err_noItemFound']			= "No entry could be found for Id %s in the table %s .";

	// Messages
	$lang['te_msg_itemCreated']				= "The entry has been added.";
	$lang['te_msg_itemSaved']				= "The entry has been saved.";
	$lang['te_msg_itemDeleted']				= "The entry has been deleted.";
	$lang['te_msg_addItemNotAllowed']		= "You are not allowed to add a new entry.";
	$lang['te_msg_deleteItemNotAllowed']	= "You are not allowed to delete an entry.";
	$lang['te_msg_valueNotUnique']			= "The field %s expects an unique value. The value %s exists already.";
	$lang['te_msg_deleteRestrict']			= "The entry can not be deleted because the field %s is already referred by the table %s .";
	
	// Texts
	$lang['te_txt_search']				= "You can search with wildcards.\nUse * for any amount of characters, e.g. '*vanni'.\nUse ? for one unknown character, e.g. 'P?ter'.\nUse ... for numeric ranges, e.g. '12...34'.";
	
	// Titles
	$lang['te_title_description']		= "Description";
	$lang['te_title_value']				= "Value";
	$lang['te_title_function']			= "Function";
	$lang['te_title_save']				= "Save";
	$lang['te_title_cancel']			= "Cancel";
	$lang['te_title_edit']				= "Edit";
	$lang['te_title_delete']			= "Delete";
	$lang['te_title_newItem']			= "Add new entry";
	$lang['te_title_up']				= "Up";
	$lang['te_title_down']				= "Down";
	$lang['te_title_unique']			= "Unique";
	$lang['te_title_field']				= "Field";
	$lang['te_title_searchValue']		= "Search value";
	$lang['te_title_search']			= "Search";
	

?>
