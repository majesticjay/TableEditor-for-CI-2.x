// In order to run the tutorial from the documentation, run these queries in your MySQL-environment


CREATE DATABASE IF NOT EXISTS TableEditor;
USE TableEditor;



CREATE TABLE IF NOT EXISTS Country (
Id Int NOT NULL AUTO_INCREMENT,
HdCreateDate DATETIME NOT NULL,
HdOrder INT NOT NULL DEFAULT 1,
Code CHAR(2) UNIQUE NOT NULL,
Description Varchar(64) NOT NULL,
Primary Key (Id)) ENGINE = InnoDB 
ROW_FORMAT = Default;



CREATE TABLE IF NOT EXISTS User (
Id Int NOT NULL AUTO_INCREMENT,
HdCreateDate DATETIME NOT NULL,
HdOrder INT NOT NULL DEFAULT 1,
Name Varchar(64) NOT NULL,
Age INT NOT NULL,
Country CHAR(2) NOT NULL,
FOREIGN KEY (Country) 
  REFERENCES Country(Code) 
  ON UPDATE CASCADE ON DELETE RESTRICT,
Primary Key (Id)) ENGINE = InnoDB 
ROW_FORMAT = Default;



CREATE TABLE IF NOT EXISTS Document (
Id Int NOT NULL AUTO_INCREMENT,
HdCreateDate DATETIME NOT NULL,
HdOrder INT NOT NULL DEFAULT 1,
Name VARCHAR(64) NOT NULL,
Filename VARCHAR(64) NOT NULL,
Primary Key (Id)) ENGINE = InnoDB 
ROW_FORMAT = Default;